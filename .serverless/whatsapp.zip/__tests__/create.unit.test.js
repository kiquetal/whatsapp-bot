const fakeEvent = require('../test/fakeEvent');

test('Create a new template',()=>{
});
