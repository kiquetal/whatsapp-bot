http GET http://localhost:4000/templates/5
