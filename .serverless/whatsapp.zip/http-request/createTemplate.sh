http POST http://localhost:4000/templates < createTemplate.json
