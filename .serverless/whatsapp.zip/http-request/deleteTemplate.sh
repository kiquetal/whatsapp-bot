http DELETE http://localhost:4000/templates/5/5ced1928-8e84-4425-89f3-247919b9a3b5
