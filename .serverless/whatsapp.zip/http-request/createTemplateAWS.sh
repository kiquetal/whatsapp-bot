http POST https://7lr319un94.execute-api.us-east-1.amazonaws.com/dev/templates x-api-key:6cgYx6cEn09oDLlHHHIZn4uXmx4OLEAH7uv4BraL	< createTemplate.json
