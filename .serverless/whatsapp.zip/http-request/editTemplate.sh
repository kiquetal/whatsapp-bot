http PUT http://localhost:4000/templates/5/2cf1f6c6-7731-4e66-8c12-33368bc6654a  < editTemplate.json
